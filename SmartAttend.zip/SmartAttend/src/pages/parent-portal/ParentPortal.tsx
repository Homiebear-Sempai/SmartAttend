export default function ParentPortal() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Parent Portal</h1>
      <p>Monitor your child’s attendance and academic progress.</p>
    </div>
  );
}
